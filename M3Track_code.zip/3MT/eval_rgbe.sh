# test visevent
CUDA_VISIBLE_DEVICES=0,1 python ./RGBE_workspace/test_rgbe_mgpus.py --script_name vipt --yaml_name deep_rgbe
