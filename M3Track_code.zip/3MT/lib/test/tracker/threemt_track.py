import math
from lib.models.ThreeMT import build_3MTTrack
from lib.test.tracker.basetracker import BaseTracker
import torch
from lib.test.tracker.vis_utils import gen_visualization
from lib.test.utils.hann import hann2d
from lib.train.data.processing_utils import sample_target
# for debug
import cv2
import os
# import vot
from lib.test.tracker.data_utils import PreprocessorMM
from lib.utils.box_ops import clip_box
from lib.utils.ce_utils import generate_mask_cond
from lib.utils.box_ops import box_cxcywh_to_xyxy, box_xywh_to_xyxy
import torch
from lib.utils.heapmap_utils import generate_heatmap
from lib.utils.ce_utils import generate_mask_cond, adjust_keep_rate
# from lib.utils.box_ops import giou_loss
from lib.utils.focal_loss import FocalLoss
import torch.nn as nn

from torchvision.ops.boxes import box_area
class ThreeMTTrack(BaseTracker):
    def __init__(self, params):
        super(ThreeMTTrack, self).__init__(params)
        network = build_3MTTrack(params.cfg, training=False)
        network.load_state_dict(torch.load(self.params.checkpoint, map_location='cpu')['net'], strict=True)
        self.cfg = params.cfg
        self.network = network.cuda()
        # self.network.eval()
        self.network.train()
        self.preprocessor = PreprocessorMM()
        self.state = None

        self.feat_sz = self.cfg.TEST.SEARCH_SIZE // self.cfg.MODEL.BACKBONE.STRIDE
        # motion constrain
        self.output_window = hann2d(torch.tensor([self.feat_sz, self.feat_sz]).long(), centered=True).cuda()

        # for debug
        if getattr(params, 'debug', None) is None:
            setattr(params, 'debug', 0)
        self.use_visdom = False #params.debug
        self.debug = params.debug
        self.frame_id = 0
        # for save boxes from all queries
        self.save_all_boxes = params.save_all_boxes,
        self.scores = []

    def initialize(self, image, info: dict):
        # forward the template once
        z_patch_arr, resize_factor, z_amask_arr  = sample_target(image, info['init_bbox'], self.params.template_factor,
                                                    output_sz=self.params.template_size)
        self.z_patch_arr = z_patch_arr
        template = self.preprocessor.process(z_patch_arr)
        with torch.no_grad():
            self.z_tensor = template

        self.box_mask_z = None
        if self.cfg.MODEL.BACKBONE.CE_LOC:
            self.template_bbox = self.transform_bbox_to_crop(info['init_bbox'], resize_factor,
                                                        template.device).squeeze(1)
            self.box_mask_z = generate_mask_cond(self.cfg, 1, template.device, self.template_bbox)

        # save states
        self.state = info['init_bbox']
        self.frame_id = 0
        T = 1
        for i in range(T):
            self.meta_update(image, seq_name=0, flag=i)

        # if self.save_all_boxes:
        #     '''save all predicted boxes'''
        #     all_boxes_save = info['init_bbox'] * self.cfg.MODEL.NUM_OBJECT_QUERIES
        #     return {"all_boxes": all_boxes_save}

    def meta_update(self, image, seq_name, flag=0):
        self.network.train()
        H, W, _ = image.shape
        x_patch_arr, resize_factor, x_amask_arr = sample_target(image, self.state, self.params.search_factor,
                                                                output_sz=self.params.search_size)  # (x1, y1, w, h)
        search = self.preprocessor.process(x_patch_arr)

        self.search_bbox = self.transform_bbox_to_crop(self.state, resize_factor,
                                                         search.device, crop_type='search').squeeze(1)

        # with torch.no_grad():
        x_tensor = search
        # merge the template and the search
        # run the transformer
        out_dict = self.network.forward(
            template=self.z_tensor, search=x_tensor, flag=flag, ce_template_mask=self.box_mask_z)

        gt_gaussian_maps = generate_heatmap([self.search_bbox], self.cfg.DATA.SEARCH.SIZE, self.cfg.MODEL.BACKBONE.STRIDE)
        gt_gaussian_maps = gt_gaussian_maps[-1].unsqueeze(1)
        fl = FocalLoss().cuda()
        l1 = nn.L1Loss().cuda()
        # add hann windows
        pred_score_map = out_dict['score_map']
        response = self.output_window * pred_score_map
        pred_boxes, best_score = self.network.box_head.cal_bbox(response, out_dict['size_map'], out_dict['offset_map'], return_score=True)
        # max_score = best_score[0][0].item()
        pred_boxes = pred_boxes.view(-1, 4)
        # Baseline: Take the mean of all pred boxes as the final result
        # pred_box = (pred_boxes.mean(
        #     dim=0) * self.params.search_size / resize_factor).tolist()  # (cx, cy, w, h) [0,1]
        # get the final box result
        # self.state = clip_box(self.map_box_back(pred_box, resize_factor), H, W, margin=10)
        num_queries = pred_boxes.size(1)
        pred_boxes_vec = box_cxcywh_to_xyxy(pred_boxes).view(-1, 4)  # (B,N,4) --> (BN,4) (x1,y1,x2,y2)
        self.gt_boxes_vec = box_xywh_to_xyxy(self.search_bbox)[:, None, :].repeat((1, num_queries, 1)).view(-1, 4).clamp(min=0.0,
                                                                                                           max=1.0)

        giou, iou = self.giou_loss(pred_boxes_vec, self.gt_boxes_vec)  # (BN,4) (BN,4)
        # compute l1 loss
        l1_loss = l1(pred_boxes_vec, self.gt_boxes_vec)  # (BN,4) (BN,4)
        # compute location loss
        location_loss = fl(response, gt_gaussian_maps)
        # weighted sum
        loss = 2.0 * giou + 5.0 * l1_loss + 1.0 * location_loss

        _ = self.network.update(loss, 0)

    def box_iou(self, boxes1, boxes2):
        """

        :param boxes1: (N, 4) (x1,y1,x2,y2)
        :param boxes2: (N, 4) (x1,y1,x2,y2)
        :return:
        """
        area1 = box_area(boxes1)  # (N,)
        area2 = box_area(boxes2)  # (N,)

        lt = torch.max(boxes1[:, :2], boxes2[:, :2])  # (N,2)
        rb = torch.min(boxes1[:, 2:], boxes2[:, 2:])  # (N,2)

        wh = (rb - lt).clamp(min=0)  # (N,2)
        inter = wh[:, 0] * wh[:, 1]  # (N,)

        union = area1 + area2 - inter

        iou = inter / union
        return iou, union

    def generalized_box_iou(self, boxes1, boxes2):
        """
        Generalized IoU from https://giou.stanford.edu/

        The boxes should be in [x0, y0, x1, y1] format

        boxes1: (N, 4)
        boxes2: (N, 4)
        """
        # degenerate boxes gives inf / nan results
        # so do an early check
        # try:
        assert (boxes1[:, 2:] >= boxes1[:, :2]).all()
        assert (boxes2[:, 2:] >= boxes2[:, :2]).all()
        iou, union = self.box_iou(boxes1, boxes2)  # (N,)

        lt = torch.min(boxes1[:, :2], boxes2[:, :2])
        rb = torch.max(boxes1[:, 2:], boxes2[:, 2:])

        wh = (rb - lt).clamp(min=0)  # (N,2)
        area = wh[:, 0] * wh[:, 1]  # (N,)

        return iou - (area - union) / area, iou

    def giou_loss(self, boxes1, boxes2):
        """

        :param boxes1: (N, 4) (x1,y1,x2,y2)
        :param boxes2: (N, 4) (x1,y1,x2,y2)
        :return:
        """
        giou, iou = self.generalized_box_iou(boxes1, boxes2)
        return (1 - giou).mean(), iou
    def track(self, image, seq_name, flag):
        H, W, _ = image.shape
        self.frame_id += 1
        x_patch_arr, resize_factor, x_amask_arr = sample_target(image, self.state, self.params.search_factor,
                                                                output_sz=self.params.search_size)  # (x1, y1, w, h)
        search = self.preprocessor.process(x_patch_arr)

        with torch.no_grad():
            x_tensor = search
            # merge the template and the search
            # run the transformer
            out_dict = self.network.forward(
                template=self.z_tensor, search=x_tensor, flag=flag, ce_template_mask=self.box_mask_z)

        # add hann windows
        pred_score_map = out_dict['score_map']
        response = self.output_window * pred_score_map
        pred_boxes, best_score = self.network.box_head.cal_bbox(response, out_dict['size_map'], out_dict['offset_map'], return_score=True)
        max_score = best_score[0][0].item()
        pred_boxes = pred_boxes.view(-1, 4)
        # Baseline: Take the mean of all pred boxes as the final result
        pred_box = (pred_boxes.mean(
            dim=0) * self.params.search_size / resize_factor).tolist()  # (cx, cy, w, h) [0,1]
        # get the final box result
        self.state = clip_box(self.map_box_back(pred_box, resize_factor), H, W, margin=10)

        self.scores.append(max_score)
        print(max_score)

        # for debug
        if self.debug == 1:
            x1, y1, w, h = self.state
            image_BGR = cv2.cvtColor(image[:,:,:3], cv2.COLOR_RGB2BGR)
            cv2.rectangle(image_BGR, (int(x1), int(y1)), (int(x1 + w), int(y1 + h)), color=(0, 0, 255), thickness=2)
            cv2.putText(image_BGR, 'max_score:' + str(round(max_score, 3)), (40, 40),
                            cv2.FONT_HERSHEY_SIMPLEX, 1,
                            (0, 255, 255), 2)
            cv2.imshow('debug_vis', image_BGR)
            cv2.waitKey(1)

        if self.save_all_boxes:
            '''save all predictions'''
            all_boxes = self.map_box_back_batch(pred_boxes * self.params.search_size / resize_factor, resize_factor)
            all_boxes_save = all_boxes.view(-1).tolist()  # (4N, )
            return {"target_bbox": self.state,
                    "all_boxes": all_boxes_save,
                    "best_score": max_score}
        else:
            return {"target_bbox": self.state,
                    "best_score": max_score}

    def map_box_back(self, pred_box: list, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return [cx_real - 0.5 * w, cy_real - 0.5 * h, w, h]

    def map_box_back_batch(self, pred_box: torch.Tensor, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box.unbind(-1) # (N,4) --> (N,)
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return torch.stack([cx_real - 0.5 * w, cy_real - 0.5 * h, w, h], dim=-1)


def get_tracker_class():
    return ThreeMTTrack
