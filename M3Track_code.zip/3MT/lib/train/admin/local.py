class EnvironmentSettings:
    def __init__(self):
        # self.workspace_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT'    # Base directory for saving network checkpoints.
        self.workspace_dir = '/scratch/zhangyong-zt00315/Trackers/3MT/3MT'    # Base directory for saving network checkpoints.
        # self.workspace_dir = '/mnt/fast/nobackup/users/zt00315/Trackers/3MT'    # Base directory for saving network checkpoints.
        self.tensorboard_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/tensorboard'    # Directory for tensorboard files.
        self.pretrained_networks = '/media/jiawen/Datasets/Codes/ViPT/ViPT/pretrained_networks'
        self.got10k_val_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/got10k/val'
        self.lasot_lmdb_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/lasot_lmdb'
        self.got10k_lmdb_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/got10k_lmdb'
        self.trackingnet_lmdb_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/trackingnet_lmdb'
        self.coco_lmdb_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/coco_lmdb'
        self.coco_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/coco'
        self.lasot_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/lasot'
        self.got10k_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/got10k/train'
        self.trackingnet_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/trackingnet'
        self.depthtrack_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/depthtrack/train'
        self.lasher_dir = '/mnt/fast/dataset/still/LasHeR/Lasher'
        self.lasher_dir = '/vol/research/facer2vm_occ/people/zhangyong/datasets/Lasher'
        # self.visevent_dir = '/media/jiawen/Datasets/Codes/ViPT/ViPT/data/visevent/train'
        self.coesot_dir = '/mnt/fast/nobackup/scratch4weeks/zt00315/CoESOT'
        self.rgbd1k_dir = '/mnt/fast/dataset/vid+depth/RGBD1K/RGBD1K_train_labelled'
        # self.rgbd1k_dir = '/mnt/fast/dataset/vid+depth/RGBD1K/RGBD1K_train_labelled'
