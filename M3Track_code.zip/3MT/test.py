import os
import cv2
import sys
from os.path import join, isdir, abspath, dirname
import numpy as np
import argparse

prj = join(dirname(__file__), '..')
if prj not in sys.path:
    sys.path.append(prj)

# from lib.test.tracker.ostrack import OSTrack
from lib.test.tracker.threemt_track import ThreeMTTrack
# from lib.test.tracker.base_track import BaseTrack
# import lib.test.parameter.mplt_track as parameters
import lib.test.parameter.threemt_track as parameters
import multiprocessing
import torch
from lib.train.dataset.depth_utils import get_x_frame
import time


save_flag = 1

def pre(path):

    # res_txt = os.path.join(res_root, name+'.txt')
    # # res_time_txt = os.path.join(res_root, name+'time.txt')
    # if os.path.exists(res_txt):
    #     return

    if os.path.exists(os.path.join(path, 'flag.txt')):
        flag = 'common'
        # dicts = ['visible', 'infrared']
        with open(os.path.join(path, 'flag.txt')) as f:
            a = f.readlines()
            f.close()
        print('%s'%(a[0]))
        if a[0] == 'rgb':
            if os.path.exists(os.path.join(path, 'rgb_ref')):
                dicts = ['color', 'rgb_ref']
            else:
                dicts = ['color', 'infrared']
        elif a[0] == 'tir':
            if os.path.exists(os.path.join(path, 'tir_ref')):
                dicts = ['tir_ref', 'infrared']
            else:
                dicts = ['color', 'infrared']
            # dicts = ['tir_ref', 'infrared']
        else:
            # print('Wrong flag! ---- %s\n'%(name))
            # print('%s'%a)
            # print('111')
            return
    else:
        flag = 'attacked'
        dicts = ['visible', 'infrared']

    return dicts, flag


def genConfig(seq_path, set_type, name):
    if set_type == 'RGBT234':
        ############################################  have to refine #############################################
        RGB_img_list = sorted(
            [seq_path + '/visible/' + p for p in os.listdir(seq_path + '/visible') if os.path.splitext(p)[1] == '.jpg'])
        T_img_list = sorted([seq_path + '/infrared/' + p for p in os.listdir(seq_path + '/infrared') if
                             os.path.splitext(p)[1] == '.jpg'])

        RGB_gt = np.loadtxt(seq_path + '/visible.txt', delimiter=',')
        T_gt = np.loadtxt(seq_path + '/infrared.txt', delimiter=',')

    elif set_type == 'GTOT':
        ############################################  have to refine #############################################
        RGB_img_list = sorted(
            [seq_path + '/v/' + p for p in os.listdir(seq_path + '/v') if os.path.splitext(p)[1] == '.png'])
        T_img_list = sorted(
            [seq_path + '/i/' + p for p in os.listdir(seq_path + '/i') if os.path.splitext(p)[1] == '.png'])

        RGB_gt = np.loadtxt(seq_path + '/groundTruth_v.txt', delimiter=' ')
        T_gt = np.loadtxt(seq_path + '/groundTruth_i.txt', delimiter=' ')

        x_min = np.min(RGB_gt[:, [0, 2]], axis=1)[:, None]
        y_min = np.min(RGB_gt[:, [1, 3]], axis=1)[:, None]
        x_max = np.max(RGB_gt[:, [0, 2]], axis=1)[:, None]
        y_max = np.max(RGB_gt[:, [1, 3]], axis=1)[:, None]
        RGB_gt = np.concatenate((x_min, y_min, x_max - x_min, y_max - y_min), axis=1)

        x_min = np.min(T_gt[:, [0, 2]], axis=1)[:, None]
        y_min = np.min(T_gt[:, [1, 3]], axis=1)[:, None]
        x_max = np.max(T_gt[:, [0, 2]], axis=1)[:, None]
        y_max = np.max(T_gt[:, [1, 3]], axis=1)[:, None]
        T_gt = np.concatenate((x_min, y_min, x_max - x_min, y_max - y_min), axis=1)

    elif set_type == 'LasHeR':
        RGB_img_list = sorted(
            [seq_path + '/visible/' + p for p in os.listdir(seq_path + '/visible') if p.endswith(".jpg")])
        T_img_list = sorted(
            [seq_path + '/infrared/' + p for p in os.listdir(seq_path + '/infrared') if p.endswith(".jpg")])

        RGB_gt = np.loadtxt(seq_path + '/visible.txt', delimiter=',')
        T_gt = np.loadtxt(seq_path + '/infrared.txt', delimiter=',')

    elif 'VTUAV' in set_type:
        RGB_img_list = sorted([seq_path + '/rgb/' + p for p in os.listdir(seq_path + '/rgb') if p.endswith(".jpg")])
        T_img_list = sorted([seq_path + '/ir/' + p for p in os.listdir(seq_path + '/ir') if p.endswith(".jpg")])

        RGB_gt = np.loadtxt(seq_path + '/rgb.txt', delimiter=' ')
        T_gt = np.loadtxt(seq_path + '/ir.txt', delimiter=' ')

    elif 'Mydataset' in set_type:
        dicts, flag = pre(seq_path)
        if flag == 'common':
            gt_rgb = name + '_1.txt'
            gt_tir = name + '_1.txt'
        else:
            gt_rgb = 'visible.txt'
            gt_tir = 'infrared.txt'

        RGB_img_list = sorted([seq_path + '/' + dicts[0] + '/' + p for p in os.listdir(seq_path + '/' + dicts[0]) if p.endswith(".jpg") or p.endswith(".png")])
        T_img_list = sorted([seq_path + '/' + dicts[1] + '/' + p for p in os.listdir(seq_path + '/' + dicts[1]) if p.endswith(".jpg") or p.endswith(".png")])

        RGB_gt = np.loadtxt(seq_path + '/' + gt_rgb, delimiter=',')
        T_gt = np.loadtxt(seq_path + '/' + gt_tir, delimiter=',')

    return RGB_img_list, T_img_list, RGB_gt, T_gt

def list2txt(bb):
    return str(bb[0]) + ',' + str(bb[1]) + ',' + str(bb[2]) + ',' + str(bb[3]) + '\n'

def save2file(res_root, name, bbox, toc):
    with open(res_root[0], 'a') as f:
        for bb in bbox:
            f.writelines(list2txt(bb))
        f.close()
    with open(res_root[1], 'a') as f:
        s = "Total time costed in video {} is {}, Fps is {}\n".format(name, str(toc / (len(bbox) - 1)), str((len(bbox)-1) / toc))
        f.writelines(s)
        f.close()

def run_sequence(seq_name, seq_home, dataset_name, yaml_name, num_gpu=1, verson='Base_t1', epoch=300, debug=0, script_name='prompt'):
    # with open("/mnt/fast/nobackup/users/zt00315/Trackers/ViPT-main/output.txt", 'a') as f:
    #     f.writelines('——————————Process sequence: ' + seq_name + '——————————————\n')
    #     f.close()
    if 'VTUAV' in dataset_name:
        seq_txt = seq_name.split('/')[1]
    else:
        seq_txt = seq_name
    # save_name = '{}_ep{}'.format(yaml_name, epoch)
    # save_name = '{}'.format(yaml_name)
    # verson = 'Base_t1'
    save_name = '{}_{}_{}'.format('Base', verson, str(epoch))
    save_path = f'./results/{dataset_name}/' + save_name + '/' + seq_txt + '.txt'
    save_folder = f'./results/{dataset_name}/' + save_name
    if not os.path.exists(save_folder):
        # print(save_folder)
        os.makedirs(save_folder)
    if os.path.exists(save_path):
        print(f'-1 {seq_name}')
        return
    # try:
    #     worker_name = multiprocessing.current_process().name
    #     worker_id = int(worker_name[worker_name.find('-') + 1:]) - 1
    #     gpu_id = worker_id % num_gpu
    #     torch.cuda.set_device(gpu_id)
    # except:
    #     pass

    if script_name == 'tracker':
        params = parameters.parameters(yaml_name, epoch)
        # mmtrack = MPLTTrack(params, 'Mydataset')  # "GTOT" # dataset_name
        # tracker = RGBT(tracker=mmtrack)
    elif script_name == 'ThreeMT':
        params = parameters.parameters(yaml_name, verson, epoch)
        mmtrack = ThreeMTTrack(params)  # "GTOT" # dataset_name
        tracker = RGBT(tracker=mmtrack)
    # with open("/mnt/fast/nobackup/users/zt00315/Trackers/ViPT-main/output.txt", 'a') as f:
    #     f.writelines('tracker built\n')
    #     f.close()
    seq_path = seq_home + '/' + seq_name
    # print('——————————Process sequence: ' + seq_name + '——————————————')
    RGB_img_list, T_img_list, RGB_gt, T_gt = genConfig(seq_path, dataset_name, seq_name)
    if len(RGB_img_list) == len(RGB_gt):
        result = np.zeros_like(RGB_gt)
    else:
        result = np.zeros((len(RGB_img_list), 4), dtype=RGB_gt.dtype)
    # result[0] = np.copy(RGB_gt[0])
    toc = 0
    pred = []
    # with open("/mnt/fast/nobackup/users/zt00315/Trackers/ViPT-main/output.txt", 'a') as f:
    #     f.writelines('start tracking\n')
    #     f.close()
    for frame_idx, (rgb_path, T_path) in enumerate(zip(RGB_img_list, T_img_list)):
        tic = time.time()
        if frame_idx == 0:
            # initialization
            image = get_x_frame(rgb_path, T_path, dtype=getattr(params.cfg.DATA, 'XTYPE', 'rgbrgb'))
            tracker.initialize(image, RGB_gt[0].tolist())  # xywh
            pred.append(RGB_gt[0].tolist())


            # with open("/mnt/fast/nobackup/users/zt00315/Trackers/ViPT-main/output.txt", 'a') as f:
            #     f.writelines('initilised\n')
            #     f.close()
        elif frame_idx > 0:
            # track
            image = get_x_frame(rgb_path, T_path, dtype=getattr(params.cfg.DATA, 'XTYPE', 'rgbrgb'))
            # rgb = cv2.imread(rgb_path)
            # rgb = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)
            # tir = cv2.imread(T_path, -1)
            # tir = cv2.cvtColor(tir, cv2.COLOR_BGR2RGB)
            # tic = time.time()
            region, confidence = tracker.track(image)  # xywh
            toc += time.time() - tic
            # result[frame_idx] = np.array(region)
            pred.append(region)
            # with open("/mnt/fast/nobackup/users/zt00315/Trackers/ViPT-main/output.txt", 'a') as f:
            #     f.writelines('trackerd\n')
            #     f.close()
            print('——————————Process sequence: ' + seq_name + ', ————Frame: ' + str(frame_idx) + '——————————')
    if save_flag:
        # with open("/mnt/fast/nobackup/users/zt00315/Trackers/ViPT-main/output.txt", 'a') as f:
        #     f.writelines('starting to save\n')
        #     f.close()
        # print('——————————33333333333Process sequence: ' + seq_name + '——————————————')
        save_time_path = f'./results/{dataset_name}/' + save_name + '/' + seq_txt + '_time.txt'
        save2file([save_path, save_time_path], seq_name, pred, toc)
        # toc += time.time() - tic
    # toc /= cv2.getTickFrequency()
    # if not debug:
    #     np.savetxt(save_path, result)
    # s = '{} , fps:{}'.format(seq_name, frame_idx / toc)
    # save_time_path = f'./RGBT_workspace/results/{dataset_name}/' + save_name + '/' + seq_txt + '.txt'
    # np.savetxt(save_time_path, s)
    # print('{} , fps:{}'.format(seq_name, frame_idx / toc))


class RGBT(object):
    def __init__(self, tracker):
        # print('——————————a——————————————')
        self.tracker = tracker

    def initialize(self, image, region):
        # print('——————————b——————————————')
        self.H, self.W, _ = image.shape
        gt_bbox_np = np.array(region).astype(np.float32)

        init_info = {'init_bbox': list(gt_bbox_np)}  # input must be (x,y,w,h)
        self.tracker.initialize(image, init_info)

    def track(self, img):
        '''TRACK'''
        # print('—————————c—————————————')
        outputs = self.tracker.track(img, seq_name=None, flag=1)
        pred_bbox = outputs['target_bbox']#
        pred_score = outputs['best_score']
        return pred_bbox, pred_score


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Run tracker on RGBT dataset.')
    parser.add_argument('--script_name', type=str, required=False, default='ThreeMT',
                        help='Name of tracking method(ostrack, prompt, ftuning).')
    parser.add_argument('--yaml_name', type=str, required=False,
                        default='dt', #ostrack_ce_ep60_prompt_iv21b_wofovea_8_onlylasher_2xa100_rgbt
                        help='Name of tracking method.')  # vitb_256_mae_ce_32x4_ep300 vitb_256_mae_ce_32x4_ep60_prompt_i32v21_onlylasher_rgbt
    parser.add_argument('--dataset_name', type=str, default='LasHeR',
                        help='Name of dataset (GTOT,RGBT234,LasHeR,VTUAVST,VTUAVLT, Mydataset).')
    parser.add_argument('--threads', default=4, type=int, help='Number of threads')
    parser.add_argument('--num_gpus', default=torch.cuda.device_count(), type=int, help='Number of gpus')
    parser.add_argument('--verson', default='Base_t1', type=str, help='Number of gpus')
    parser.add_argument('--epoch', default=35, type=int, help='epochs of ckpt')
    parser.add_argument('--mode', default='sequential', type=str, help='sequential or parallel')
    parser.add_argument('--debug', default=0, type=int, help='to vis tracking results')
    parser.add_argument('--video', default='2girl', type=str, help='specific video name')
    args = parser.parse_args()

    yaml_name = args.yaml_name
    dataset_name = args.dataset_name
    # path initialization
    seq_list = None
    if dataset_name == 'GTOT':
        seq_home = '/home/lz/Videos/GTOT'
        seq_list = [f for f in os.listdir(seq_home) if isdir(join(seq_home, f))]
        seq_list.sort()
    elif dataset_name == 'RGBT234':
        seq_home = '/media/jiawen/Datasets/Tracking/DATASET_TEST/RGBT234'
        seq_list = [f for f in os.listdir(seq_home) if isdir(join(seq_home, f))]
        seq_list.sort()
    elif dataset_name == 'LasHeR':
        # dataset_root = '/mnt/fast/nobackup/scratch4weeks/zt00315/Lasher'
        dataset_root = '/vol/research/facer2vm_occ/people/zhangyong/datasets/Lasher'
        list_path = os.path.join(dataset_root, "testingsetList.txt")
        sequence_list_file = open(list_path, "r")
        seq_list = sequence_list_file.readlines()
        sequence_list_file.close()
        seq_list = [seq_list[i].split('\n')[0] for i in range(len(seq_list))]
        seq_home = dataset_root
    elif dataset_name == 'VTUAVST':
        seq_home = '/mnt/6196b16a-836e-45a4-b6f2-641dca0991d0/VTUAV/test/short-term'
        with open(join(join(seq_home, 'VTUAV-ST.txt')), 'r') as f:
            seq_list = f.read().splitlines()
    elif dataset_name == 'VTUAVLT':
        seq_home = '/mnt/6196b16a-836e-45a4-b6f2-641dca0991d0/VTUAV/test/long-term'
        with open(join(seq_home, 'VTUAV-LT.txt'), 'r') as f:
            seq_list = f.read().splitlines()
    elif dataset_name == 'Mydataset':
        seq_home = '/mnt/fast/nobackup/scratch4weeks/zt00315/Mydataset'
        with open(join(seq_home, 'list.txt'), 'r') as f:
            seq_list = f.read().splitlines()
    else:
        raise ValueError("Error dataset!")
    # print('——————————z——————————————')
    start = time.time()
    if args.mode == 'parallel':
        sequence_list = [
            (s, seq_home, dataset_name, args.yaml_name, args.num_gpus, args.verson, args.epoch, args.debug, args.script_name) for s
            in seq_list]
        multiprocessing.set_start_method('spawn', force=True)
        with multiprocessing.Pool(processes=args.threads) as pool:
            pool.starmap(run_sequence, sequence_list)
    else:
        seq_list = [args.video] if args.video != '' else seq_list
        sequence_list = [
            (s, seq_home, dataset_name, args.yaml_name, args.num_gpus, args.verson, args.epoch, args.debug, args.script_name) for s
            in seq_list]
        for seqlist in sequence_list:
            run_sequence(*seqlist)
    print(f"Totally cost {time.time() - start} seconds!")
