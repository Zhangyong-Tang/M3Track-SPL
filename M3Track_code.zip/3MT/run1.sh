pwd
cd /mnt/fast/nobackup/users/zt00315
source .bashrc
source activate vipt
export PYTHONPATH=/mnt/fast/nobackup/users/zt00315/Trackers/ViPT-main/ViPT-main:$PYTHONPATH
cd /mnt/fast/nobackup/users/zt00315/Trackers/ViPT-main/ViPT-main

/mnt/fast/nobackup/users/zt00315/anaconda/envs/vipt/bin/python lib/train/run_training.py
